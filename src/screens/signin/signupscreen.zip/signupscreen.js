import React, { useEffect, useState, useRef } from "react";
import { StatusBar, TouchableOpacity, Text, TextInput, View, Image, SafeAreaView, StyleSheet, ImageBackground, ToastAndroid, Keyboard, BackHandler } from "react-native";
import logo from '../../assets/images/logo.png';
// import logo from './../../assets/images/logo.png'
import google from '../../assets/images/google_logo.png';
import facebook from '../../assets/images/facebook_logo.png';
import Linking from 'react-native/Libraries/Linking/Linking';
import { useNavigation, useFocusEffect, CommonActions  } from "@react-navigation/native";
import CountryPicker from 'react-native-country-picker-modal';
import { wp, hp } from "../common/responsive"
import { fonts } from "../../components/customfont";
// import {Poppins} from "../components/customfont";
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import Feather from "react-native-vector-icons/Feather";
import { Animated, Easing } from 'react-native';
import { ENDPOINTS } from "../../environments/environment";
import Icon from "react-native-vector-icons/Ionicons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import LinearGradient from 'react-native-linear-gradient';


export default function Signup() {
  const [number, setNumber] = useState('');
  const navigation = useNavigation();
  const [email, setemail] = useState('');
  const [Password, setpassword] = useState('');
  const [countryCode, setCountryCode] = useState('RO');
  const [callingCode, setCallingCode] = useState('+40');
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const spinValue = useRef(new Animated.Value(0)).current;
  const [error, setError] = useState('');
  const [activeInput, setActiveInput] = useState(null);
  const [showPassword, setShowPassword] = useState(false);

  const backPressCount = useRef(0);
  const backPressTimeout = useRef(null);
  const phoneInputRef = useRef(null);

  useEffect(() => {
    GoogleSignin.configure({
      webClientId: '84964920502-2ibkj7eo9to0e33mlagsh8imf1vigc4s.apps.googleusercontent.com',
    });
  })

  useEffect(() => {
    if (number.length > 0) {
      setActiveInput('phone');
    } else if (email.length > 0 || Password.length > 0) {
      setActiveInput('login');
    } else {
      setActiveInput(null);
    }
  }, [number, email, Password, activeInput]);

  async function onGoogleButtonPress() {

    await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
    // Get the users ID token
    const signInResult = await GoogleSignin.signIn();

    idToken = signInResult.data?.idToken;
    if (!idToken) {
      idToken = signInResult.idToken;
    }
    if (!idToken) {
      throw new Error('No ID token found');
    }

    const googleCredential = auth.GoogleAuthProvider.credential(signInResult.data.token);

    return auth().signInWithCredential(googleCredential);
  }

  const handleGoogleLogin = () => {
    const googleSignupURL = "https://accounts.google.com/v3/signin/identifier";
    Linking.openURL(googleSignupURL);
  };

  const handleFacebookLogin = () => {
    const facebookSignupURL = "https://www.facebook.com/reg/";
    Linking.openURL(facebookSignupURL);
  };

  const handleSubmit = () => {
    // navigation.navigate('Mapsearch')
    if (number) {
      handleverfication(callingCode + number);
    } else if (email || Password) {
      handleLogin();
    } else {
      setError('Please enter Phone Number or Email and Password');
      // setTimeout(() => {
      //   setError('');
      // }, 3000);
    }
  };

  const handleverfication = async (number) => {
    startSpin()
    try {
      setLoading(true);
      //validate the mobile number already exist in the DB
      const checkSignIn = await signInValidation(number);
      if(!checkSignIn){
        return
      }
      const response = await fetch(ENDPOINTS.whatsappValidation(number), {
        method: 'POST',
      });
      console.log("whats app payload", number)
      let responseData = await response.json();
      console.log("response in wharsapp----", responseData)
      if (response.ok) {
        setNumber('')
        navigation.navigate('numberverify', { phonenumber: number });
      }
    } catch (error) {
      const errorMessage = error?.message || 'Failed to send verification code.';
      setError(errorMessage);
    } finally {
      setLoading(false)
      // setTimeout(() => {
      //   setError('');
      // }, 3000);
    }
  };

  const signInValidation = async (number) => {
    try {
      setLoading(true);
      // console.log(environment.apiBaseUrl+"login")
      const response = await fetch(ENDPOINTS.phoneValidationSignIn(number), {
        method: 'POST',
      });
      let responseData = await response.json();
      console.log("response in signin----", responseData)
      if (response.ok) {
        console.log("response ok in signin validation")
        return true
      } else if (responseData.statusCode === 500) {
        setError('')
        ToastAndroid.show(responseData.message, ToastAndroid.SHORT);
        // navigation.replace('Register')
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{ name: 'Register' }],
          })
        );
      }
    } catch (error) {
      const errorMessage = error?.message || 'Failed to proceed sign in!';
      // setError(errorMessage);
    } finally {
      setLoading(false)
    }
  };

  const handleRegister = () => {
    setActiveInput(null);
    setNumber('');
    setemail('');
    setpassword('');
    setError('')
    navigation.navigate('Register');
  };

  const onSelectCountry = (country) => {
    setCountryCode(country.cca2);
    setCallingCode(`+${country.callingCode[0]}`);
    setModalVisible(false);
  };

  const startSpin = () => {
    Animated.loop(
      Animated.timing(spinValue, {
        toValue: 1,
        duration: 1000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
  };
  const handleInputChange = (field, value) => {
    if (field === "email") setemail(value);
    if (field === "password") setpassword(value);

    if (field === 'email' && value) {
      setError('');
    }
    if (field === 'password' && value) {
      setError('');
    }
  }

  const handleLogin = async () => {
    const showError = (message) => {
      setError(message);
    };
    if (!email || !Password) {
      showError('Please enter both email and password');
      // setTimeout(() => {
      //   setError('');
      // }, 3000);
      return;
    }

    startSpin();

    // navigation.navigate('Mapsearch');
    try {
      setLoading(true);
      // console.log(environment.apiBaseUrl+"login")
      const response = await fetch(ENDPOINTS.login, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password: Password,
        }),
      });

      let responseData = await response.json();

      if (response.ok) {
        console.log('response', responseData)
        AsyncStorage.setItem("accessToken", responseData.accessToken)
        AsyncStorage.setItem("refreshToken", responseData.refreshToken)
        AsyncStorage.setItem("userId", responseData.userId)
        AsyncStorage.setItem("emailId", email)

        showError('Logged in successfully');
        setemail('')
        setpassword('')
        setError('');
        navigation.navigate('Mapsearch')
      } else {
        if (responseData.statusCode === 400) {
          showError(responseData.messages || 'Sign up failed');
          console.error('Error Response:', responseData);
        } else {
          showError(responseData.error || 'Sign up failed');
          console.error('Error Response:', responseData.error);
        }
      }
    } catch (error) {
      const errorMessage = error?.message || 'Sign in falied!';
      showError(errorMessage);
    } finally {
      setLoading(false)
      // setTimeout(() => {
      //   setError('');
      // }, 3000);
    }
  };

  useEffect(() => {
    setLoading(false);
  }, []);

  // useEffect(() => {
  //   const backAction = () => {

  //     setActiveInput(null);
  //     setNumber('');
  //     setemail('');
  //     setpassword('');
  //     BackHandler.exitApp();

  //     return true;
  //   };

  //   const backHandler = BackHandler.addEventListener(
  //     'hardwareBackPress',
  //     backAction
  //   );

  //   return () => backHandler.remove();
  // }, []);


  const handleforget = () => {
    setActiveInput(null);
    setNumber('');
    setemail('');
    setpassword('');
    setError('')
    navigation.navigate('forgetpassword')
  }

  const handlenumberReset = () => {
    setNumber('');
    setActiveInput('login');
  };

  const handleReset = () => {
    setemail('');
    setpassword('');
    setActiveInput('phone');
  };

  useEffect(() => {
    const handleBackPress = () => {
      if (Keyboard.isVisible()) {
        Keyboard.dismiss();
        return true;
      }

      if (activeInput) {
        setActiveInput(null);
        setNumber('');
        setemail('');
        setpassword('');
        return true;
      }

      if (backPressCount.current === 1) {
        setNumber('');
        setemail('');
        setpassword('');
        BackHandler.exitApp();
        return true;
      }

      backPressCount.current += 1;
      ToastAndroid.show("Press back again to exit", ToastAndroid.SHORT);

      backPressTimeout.current = setTimeout(() => {
        backPressCount.current = 0;
      }, 2000);

      return true;
    };

    const backHandler = BackHandler.addEventListener("hardwareBackPress", handleBackPress);
    return () => {
      backHandler.remove();
      if (backPressTimeout.current) {
        clearTimeout(backPressTimeout.current);
      }
    };
  }, [activeInput]);

  useFocusEffect(
    React.useCallback(() => {
      return () => {
        setNumber('')
        setemail('')
        setpassword('')
      };
    }, [])
  );

  return (
    <SafeAreaView style={styles.container}>
      <Image source={logo} style={styles.logo} />
      <View style={styles.overlay}>
        <Text style={[styles.text]}>
        Welcome to klass Ride!
        </Text>
        <Text style={[styles.text1]}>
          Find the best ride at the best price,
        </Text>
        <Text style={[styles.text1]}>all in one place</Text>
        
        
        <View style={{ borderRadius: 20, overflow: 'hidden' }}>
        <LinearGradient
          colors={['#FF6200', '#4800AC']} // Gradient colors
          start={{ x: 0.28, y: 0 }} // Start point for 105.21°
          end={{ x: 0.94, y: 1 }}
          style={styles.gradientBorder}
        >
          <View style={styles.innerContainer}>
            <TouchableOpacity
              onPress={() => {
                setActiveInput('phone');
                setModalVisible(true);
              }}
              style={styles.countryCodeSelector}
            >
              <CountryPicker
                countryCode={countryCode}
                withFilter
                withFlag
                withAlphaFilter
                withCallingCode
                onSelect={onSelectCountry}
                visible={modalVisible}
                onClose={() => setModalVisible(false)}
              />
              <Text style={styles.countryCode}>{callingCode}</Text>
            </TouchableOpacity>

            <TextInput
              style={[styles.input, { flex: 1 }]}
              value={number}
              editable={activeInput === 'phone' || activeInput === null}
              onChangeText={(text) => {
                const numericText = text.replace(/[^0-9]/g, '');
                setNumber(numericText);
                setError('');
              }}
              onFocus={() => setActiveInput('phone')}
              keyboardType="numeric"
              placeholder="Enter Number"
              placeholderTextColor="#cccccc"
              maxLength={15}
            />
            {number.length > 0 && (
              <TouchableOpacity
                onPress={() => {
                  setNumber('');
                  setActiveInput(null);
                  setTimeout(() => phoneInputRef.current?.focus(), 0); // Keep the cursor after clearing
                }}
                style={styles.icon1}
              >
                <MaterialCommunityIcons name="close-circle" size={18} color="#cccccc" />
              </TouchableOpacity>
            )}
          </View>
        </LinearGradient>
      </View>


  
   
        {/* Login Input Section */}
        <Text style={styles.login}>--- OR Login ---</Text>
        <View style={styles.EmailinputContainer}>
  <LinearGradient
    colors={['#FF6200', '#4800AC']} // Gradient colors
    start={{ x: 0.28, y: 0 }} // Start point for 105.21°
    end={{ x: 0.94, y: 1 }} // End point for 64.29%
    style={styles.gradientBorder}
  >
    <View style={styles.innerContainer}>
      <TextInput
        style={styles.inputEmail}
        value={email}
        editable={activeInput === 'login' || activeInput === null}
        onChangeText={(value) => handleInputChange('email', value)}
        placeholder="Email Address"
        keyboardType="email-address"
        placeholderTextColor="#CBC0C0"
        onFocus={() => setActiveInput('login')}
      />
      {email.length > 0 && (
        <TouchableOpacity
          onPress={() => {
            setemail('');
            setActiveInput(null);
          }}
          style={styles.icon1}
        >
          <MaterialCommunityIcons name="close-circle" size={18} color="#cccccc" />
        </TouchableOpacity>
      )}
    </View>
  </LinearGradient>
</View>

      <View style={{ borderRadius: 10, overflow: 'hidden' }}>
        <LinearGradient
          colors={['#FF6200', '#4800AC']} 
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.gradientBorder}
        >
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.inputPassword}
              value={Password}
              editable={activeInput === 'login' || activeInput === null}
              onChangeText={(value) => handleInputChange('password', value)}
              placeholder="Password"
              keyboardType="default"
              secureTextEntry={!showPassword}
              placeholderTextColor="#CBC0C0"
              onFocus={() => setActiveInput('login')}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={styles.icon}
            >
              <Icon name={showPassword ? 'eye' : 'eye-off'} size={20} color="#cccccc" />
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </View>


        <View style={styles.usertab}>
          <TouchableOpacity activeOpacity={0.8}>
            <Text style={styles.forget} onPress={handleforget}>Forgot Password?</Text>
          </TouchableOpacity>
        </View>
        <View style={[styles.buttonspace, { marginTop: error ? 0 : hp(2) }]}>
            <TouchableOpacity activeOpacity={0.8} style={styles.button}>
              <Text style={styles.submitbutton} onPress={handleSubmit}>SUBMIT</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.registerContainer}>
        <Text style={styles.Acc} >Don't have an account?{' '} </Text>
        <View style={[styles.buttonspace]}>
        <TouchableOpacity activeOpacity={0.8} onPress={handleRegister} style={styles.button}>            
              <Text style={styles.submitbutton}>Register</Text>              
          </TouchableOpacity>
          </View>
          </View>
        <View style={styles.lap}>
          <Text style={[styles.log, { fontFamily: fonts.Poppins }]}>or Sign up with</Text>

          <View style={styles.socialButtons}>
            <TouchableOpacity activeOpacity={0.8} style={styles.google} onPress={onGoogleButtonPress}>
              <Image source={google} style={styles.iconImage} />
              <Text style={styles.buttonText}></Text>
            </TouchableOpacity>

            <TouchableOpacity activeOpacity={0.8} style={styles.facebook} onPress={handleFacebookLogin}>
              <Image source={facebook} style={styles.iconImage} />
              <Text style={styles.buttonText}></Text>
            </TouchableOpacity>
          </View>

          {error && (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
              <TouchableOpacity onPress={() => setError('')} style={styles.closeIcon}>
                <Icon name="close" size={20} color="white" />
              </TouchableOpacity>
            </View>
          )}

          
        </View>
      </View>
      {loading && (
        <View style={styles.loaderOverlay}>
          <Animated.View
            style={{
              transform: [
                {
                  rotate: spinValue.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0deg', '360deg'],
                  }),
                },
              ],
            }}
          >
            <Feather name="loader" size={40} color="#ff7d00" />
          </Animated.View>
        </View>
      )}
    </SafeAreaView>
  );
};



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#303336",
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 15,
  },
  logo: {
    width: wp(80),
    height: hp(16),
    marginTop: hp(2),
    resizeMode: "contain"
  },
  overlay: {
    padding: wp(5),
    elevation: 10,
  },
  text: {
    color: "#CBC0C0",
    fontFamily: fonts.NATS,
    fontSize: wp(8),
    marginRight: wp(5),
    textAlign:"center"
  },
  text1: {
    color: "#CBC0C0",
    fontFamily: fonts.NATS,
    fontSize: 13,
    marginRight: wp(5),
    marginTop: hp(-2),
    textAlign:"center"
  },
  innerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#22272B',
    borderRadius: 20, 
    // paddingVertical: 3,
    // width:wp(90)
  },
  gradientWrapper: {
    borderRadius: 20, 
    overflow: 'hidden',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#22272B', 
    borderRadius: 20,
    fontFamily: fonts.NATS,
    color: '#ffffff',
    fontSize: hp(20),
    marginTop: hp(1),
    height: hp(6),
    overflow: 'hidden',
  },
  countryCodeSelector: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 1,
    alignItems: 'center',
    color: '#cccccc',
  },
  countryCode: {
    fontSize: wp(4),
    color: '#cccccc',
  },
  input: {
    fontSize: wp(4),
    letterSpacing: 2,
    color: '#cccccc',
    backgroundColor: '#22272B',
  },
  gradientBorder: {
    padding: 1,
    borderRadius: 20, 
  },
  inputEmail: {
    flex: 1,
    fontSize: wp(4),
    color: '#cccccc',
    letterSpacing: 2,
    backgroundColor: '#22272B',
    borderRadius: 20,
  },
  EmailinputContainer: {
    width: wp(90),
    marginTop: hp(2),
    marginBottom: hp(1),
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#22272B', 
    borderRadius: 20,
    paddingHorizontal: wp(3),
    height: hp(6),
  },
  icon: {
    // paddingHorizontal: wp(10),
    position: 'absolute',
    right: wp(5)
  },
  icon1: {
    position: 'absolute',
    right: wp(5)
    // paddingHorizontal: wp(4.5),
  },
  inputPassword: {
    flex: 1,
    fontSize: wp(4),
    color: '#cccccc',
    letterSpacing: 2,
    paddingVertical: 0,
  },
  forget: {
    color: "orange",
    // marginTop: hp(1),
    fontSize: wp(4),
    textDecorationLine: "underline",
    // marginLeft: wp(58),
  },
  lap: {
    marginTop: hp(-1),
    alignItems: 'center',
    justifyContent: 'center'

  },
  login: {
    color: "white",
    alignSelf: "center",
    marginTop: hp(2),
    fontFamily: fonts.Poppins,
    color: '#cccccc',
  },
  usertab: {
    flexDirection: 'row',
    justifyContent: "flex-end"
  //   // bottom: 19,
  //   // alignItems: "flex-start",
  //   // flexDirection: "row"
  },
  Acc: {
    color: '#cccccc',
    fontSize: wp(4),
    textAlign:"center"
  },
  code: {
    color: "orange",
    // textAlign: "center",
    textDecorationLine: "underline",
    // marginTop:hp
    // fontFamily: fonts.Poppins,
    fontSize: wp(4),
  },
  log: {
    marginTop: hp(6),
    color: "#ffffff",
    textAlign: 'center',
    fontSize: wp(4.5),
    marginBottom: hp(-3),
    fontFamily: fonts.Poppins
  },
  buttonspace: {
    marginTop: hp(2),
    // position: 'relative',
  },
  button: {
    backgroundColor: "#D3770C",
    borderRadius: 12,
    width: wp(50),
    height: hp(5),
    alignSelf: 'center',
  },
  submitbutton: {
    color: '#ffffff',
    fontSize: wp(4.5),
    fontWeight: 'bold',
    textAlign: "center",
    marginTop: hp(0.9),
    letterSpacing: 1,
  },
  socialButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: wp(30),
    height: hp(7),
    // marginLeft: wp(29),
    marginTop: hp(4),
  },
  google: {
    backgroundColor: '#262626',
    borderRadius: 10,
    width: '43%',
    alignItems: 'center',
    padding: wp(4),
    flexDirection: 'row',
  },
  facebook: {
    backgroundColor: '#262626',
    borderRadius: 10,
    width: '43%',
    alignItems: 'center',
    padding: wp(4),
    flexDirection: 'row',
  },
  reg: {
    color: 'white',
    marginLeft: wp(31),
    marginTop: hp(2),
    fontSize: wp(3.5),
  },
  buttonText: {
    fontSize: wp(4.5),
    color: '#000000',
    marginLeft: wp(2),
  },
  iconImage: {
    width: wp(10),
    height: wp(10),
    marginLeft: wp(-2.5),
  },
  registerText: {
    color: "#0066ff",
    marginLeft: wp(35),
    textDecorationColor: "blue",
    textDecorationLine: "underline",
  },
  loaderOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 10,
  },
  errorContainer: {
    backgroundColor: "#800020",
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
    width: "90%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 5,
    marginBottom: 5,
    borderColor: 'grey',
    borderWidth: 1,
    gap: 1
  },
  errorText: {
    color: "white",
    fontSize: wp(3.5),
    flexShrink: 1,
  },
  closeIcon: {
    // marginLeft: 10,
    // padding: 5,
  },
  // errorText: {
  //   color: '#D3770C',
  //   justifyContent: "center",
  //   alignItems: "center",
  //   textAlign: 'center',
  //   fontSize: wp(3.5),
  //   margin: hp(1),
  //   // textAlign: 'justify',
  //   // backgroundColor: 'black',
  //   borderRadius: 10,
  //   // paddingHorizontal: wp(5)
  // },
});
